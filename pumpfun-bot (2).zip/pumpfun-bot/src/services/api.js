const http = require('http');
const { getBalance, getPublicKey } = require('./userWallet');
const { getTokenInfo, getTrendingCoins, formatMarketCap } = require('./pumpfun');
const store = require('../utils/store');
const autoStore = require('../utils/autoStore');
const logger = require('../utils/logger');

const PORT = process.env.API_PORT || 3000;

/**
 * Simple JSON API for the Mini App
 * Endpoints:
 *   GET /api/wallet?chatId=xxx        → balance + address
 *   GET /api/history?chatId=xxx       → trade history
 *   GET /api/strategies?chatId=xxx    → active strategies
 *   GET /api/stats?chatId=xxx         → dashboard stats
 *   POST /api/buy                     → trigger buy
 *   POST /api/sell                    → trigger sell
 */

let botRef = null;

function startApiServer(bot) {
  botRef = bot;

  const server = http.createServer(async (req, res) => {
    // CORS headers — allow Mini App to call this API
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Content-Type', 'application/json');

    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    const url = new URL(req.url, `http://localhost:${PORT}`);
    const path = url.pathname;
    const chatId = url.searchParams.get('chatId');

    try {
      // ── GET /api/wallet ──────────────────────────────────────
      if (path === '/api/wallet' && req.method === 'GET') {
        if (!chatId) return sendError(res, 'chatId required');

        const wallet = store.getUserWallet(chatId);
        if (!wallet) {
          return send(res, { address: null, balance: 0, balanceUsd: 0 });
        }

        const balance = await getBalance(chatId).catch(() => 0);
        const solPrice = 175; // approximate — replace with live price if needed

        send(res, {
          address: wallet.publicKey,
          balance: parseFloat(balance.toFixed(4)),
          balanceUsd: parseFloat((balance * solPrice).toFixed(2)),
        });
      }

      // ── GET /api/stats ───────────────────────────────────────
      else if (path === '/api/stats' && req.method === 'GET') {
        if (!chatId) return sendError(res, 'chatId required');

        const history = store.getTradeHistory ? store.getTradeHistory(chatId) : [];
        const strategies = autoStore.getUserStrategies(chatId);
        const watchlist = store.getUserWatchlist(chatId);
        const buys = history.filter(h => h.type === 'buy');
        const sells = history.filter(h => h.type === 'sell');
        const wins = history.filter(h => h.pnl > 0).length;

        send(res, {
          totalTrades: history.length,
          buys: buys.length,
          sells: sells.length,
          strategies: strategies.filter(s => s.active).length,
          watching: watchlist.length,
          winRate: history.length > 0 ? Math.round((wins / history.length) * 100) : 0,
          feesPaid: parseFloat((history.length * 0.001).toFixed(3)),
        });
      }

      // ── GET /api/history ─────────────────────────────────────
      else if (path === '/api/history' && req.method === 'GET') {
        if (!chatId) return sendError(res, 'chatId required');

        const history = store.getTradeHistory ? store.getTradeHistory(chatId) : [];
        send(res, { history });
      }

      // ── GET /api/strategies ──────────────────────────────────
      else if (path === '/api/strategies' && req.method === 'GET') {
        if (!chatId) return sendError(res, 'chatId required');

        const strategies = autoStore.getUserStrategies(chatId);
        send(res, { strategies });
      }

      // ── POST /api/buy ────────────────────────────────────────
      else if (path === '/api/buy' && req.method === 'POST') {
        const body = await readBody(req);
        const { chatId: cid, mint, amount } = body;

        if (!cid || !mint || !amount) {
          return sendError(res, 'chatId, mint and amount required');
        }

        // Send command to bot
        if (botRef) {
          const fakeMsg = { chat: { id: cid, type: 'private' }, from: { id: cid } };
          const { handleBuy } = require('../handlers/trading');
          handleBuy(botRef, fakeMsg, `${mint} ${amount}`, true);
        }

        send(res, { success: true, message: 'Buy order submitted' });
      }

      // ── POST /api/sell ───────────────────────────────────────
      else if (path === '/api/sell' && req.method === 'POST') {
        const body = await readBody(req);
        const { chatId: cid, mint, percent } = body;

        if (!cid || !mint || !percent) {
          return sendError(res, 'chatId, mint and percent required');
        }

        if (botRef) {
          const fakeMsg = { chat: { id: cid, type: 'private' }, from: { id: cid } };
          const { handleSell } = require('../handlers/trading');
          handleSell(botRef, fakeMsg, `${mint} ${percent}`, true);
        }

        send(res, { success: true, message: 'Sell order submitted' });
      }

      // ── POST /api/strategy/cancel ────────────────────────────
      else if (path === '/api/strategy/cancel' && req.method === 'POST') {
        const body = await readBody(req);
        const { chatId: cid, id } = body;
        autoStore.removeStrategy(cid, id);
        send(res, { success: true });
      }

      // ── POST /api/strategy/toggle ────────────────────────────
      else if (path === '/api/strategy/toggle' && req.method === 'POST') {
        const body = await readBody(req);
        const { chatId: cid, id } = body;
        const isActive = autoStore.pauseStrategy(cid, id);
        send(res, { success: true, active: isActive });
      }

      // ── GET /api/token ───────────────────────────────────────
      else if (path === '/api/token' && req.method === 'GET') {
        const mint = url.searchParams.get('mint');
        if (!mint) return sendError(res, 'mint required');
        const info = await getTokenInfo(mint);
        send(res, info || {});
      }

      // ── GET /api/trending ────────────────────────────────────
      else if (path === '/api/trending' && req.method === 'GET') {
        const coins = await getTrendingCoins(10);
        send(res, { coins });
      }

      else {
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Not found' }));
      }
    } catch (err) {
      logger.error('API error:', err.message);
      sendError(res, err.message, 500);
    }
  });

  server.listen(PORT, () => {
    logger.info(`🌐 Mini App API running on port ${PORT}`);
  });
}

function send(res, data) {
  res.writeHead(200);
  res.end(JSON.stringify(data));
}

function sendError(res, msg, code = 400) {
  res.writeHead(code);
  res.end(JSON.stringify({ error: msg }));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try { resolve(JSON.parse(body)); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

module.exports = { startApiServer };
